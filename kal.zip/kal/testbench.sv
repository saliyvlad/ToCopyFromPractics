module testbench();
    logic clk, reset;
    
    // Сигналы для dtrigger
    logic d_dtr, q_dtr, q_dtr_expected;
    
    // Сигналы для SyncRes
    logic reset_sync, d_sync, q_sync, q_sync_expected;
    
    // Сигналы для dtrigger_en
    logic en_en, d_en, q_en, q_en_expected;
    
    // Сигналы для ProjVL
    logic [3:0] q_proj, q_proj_expected;
    
    // Сигналы для ParallelSerialRegister
    logic load_psr, serial_out_psr, serial_out_expected;
    logic [3:0] parallel_data_psr;
    
    // Переменные для тестирования
    logic [31:0] vectornum, errors;
    
    // Размерность векторов для каждого модуля
    // dtrigger: {D, expected_Q} - 2 бита
    logic [1:0] testvectors_dtr [0:100];
    
    // SyncRes: {reset, D, expected_Q} - 3 бита
    logic [2:0] testvectors_sync [0:100];
    
    // dtrigger_en: {EN, D, expected_Q} - 3 бита
    logic [2:0] testvectors_en [0:100];
    
    // ProjVL: {expected_Q[3:0]} - 4 бита
    logic [3:0] testvectors_proj [0:100];
    
    // ParallelSerialRegister: {Load, ParallelData[3:0], expected_SerialOut} - 6 бит
    logic [5:0] testvectors_psr [0:100];
    
    // Инстансы модулей
    dtrigger u_dtrigger (
        .D(d_dtr),
        .CLK(clk),
        .Q(q_dtr)
    );
    
    SyncRes u_syncres (
        .D(d_sync),
        .CLK(clk),
        .reset(reset_sync),
        .Q(q_sync)
    );
    
    dtrigger_en u_dtrigger_en (
        .D(d_en),
        .CLK(clk),
        .EN(en_en),
        .Q(q_en)
    );
    
    ProjVL u_projvl (
        .Clk(clk),
        .Reset(reset),
        .Q(q_proj)
    );
    
    ParallelSerialRegister u_psr (
        .Clk(clk),
        .Reset(reset),
        .Load(load_psr),
        .ParallelData(parallel_data_psr),
        .SerialOut(serial_out_psr)
    );
    
    // Генерация тактового сигнала
    always begin
        clk = 1; #5; clk = 0; #5;
    end
    
    // Процесс сброса и загрузки тестов
    initial begin
        // Загрузка тестовых векторов из файлов
        $readmemb("test_dtrigger.txt", testvectors_dtr);
        $readmemb("test_syncres.txt", testvectors_sync);
        $readmemb("test_enable.txt", testvectors_en);
        $readmemb("test_projvl.txt", testvectors_proj);
        $readmemb("test_shiftreg.txt", testvectors_psr);
        
        vectornum = 0;
        errors = 0;
        
        // Сброс
        reset = 1; #27; reset = 0;
        
        // Запуск тестов
        fork
            test_dtrigger();
            test_syncres();
            test_dtrigger_en();
            test_projvl();
            test_shiftreg();
        join
        
        // Вывод итогов
        #100;
        $display("\n=========================================");
        $display("Total tests completed with %d errors", errors);
        $display("=========================================");
        $stop;
    end
    
    // ТЕСТ 1: D-триггер
    task test_dtrigger();
        logic [1:0] vector;
        logic expected_q;
        integer local_errors = 0;
        
        $display("\n========== TEST 1: D-trigger ==========");
        vectornum = 0;
        
        forever begin
            @(posedge clk);
            #1;
            vector = testvectors_dtr[vectornum];
            if (vector === 2'bx) begin
                $display("D-trigger: %d tests completed with %d errors", vectornum, local_errors);
                errors += local_errors;
                break;
            end
            
            {d_dtr, expected_q} = vector;
            
            @(negedge clk);
            if (~reset) begin
                if (q_dtr !== expected_q) begin
                    $display("Error [D-trigger]: inputs D=%0b, expected Q=%0b, actual Q=%0b", 
                             d_dtr, expected_q, q_dtr);
                    local_errors++;
                end
                vectornum++;
            end
        end
    endtask
    
    // ТЕСТ 2: Триггер с синхронным сбросом
    task test_syncres();
        logic [2:0] vector;
        logic reset_val, d_val, expected_q;
        integer local_errors = 0;
        
        $display("\n========== TEST 2: Synchronous Reset ==========");
        vectornum = 0;
        
        forever begin
            @(posedge clk);
            #1;
            vector = testvectors_sync[vectornum];
            if (vector === 3'bx) begin
                $display("Sync Reset: %d tests completed with %d errors", vectornum, local_errors);
                errors += local_errors;
                break;
            end
            
            {reset_val, d_val, expected_q} = vector;
            reset_sync = reset_val;
            d_sync = d_val;
            
            @(negedge clk);
            if (~reset) begin
                if (q_sync !== expected_q) begin
                    $display("Error [Sync Reset]: reset=%0b, D=%0b, expected Q=%0b, actual Q=%0b", 
                             reset_val, d_val, expected_q, q_sync);
                    local_errors++;
                end
                vectornum++;
            end
        end
    endtask
    
    // ТЕСТ 3: Триггер с разрешающим входом
    task test_dtrigger_en();
        logic [2:0] vector;
        logic en_val, d_val, expected_q;
        integer local_errors = 0;
        
        $display("\n========== TEST 3: Enable Trigger ==========");
        vectornum = 0;
        
        forever begin
            @(posedge clk);
            #1;
            vector = testvectors_en[vectornum];
            if (vector === 3'bx) begin
                $display("Enable Trigger: %d tests completed with %d errors", vectornum, local_errors);
                errors += local_errors;
                break;
            end
            
            {en_val, d_val, expected_q} = vector;
            en_en = en_val;
            d_en = d_val;
            
            @(negedge clk);
            if (~reset) begin
                if (q_en !== expected_q) begin
                    $display("Error [Enable]: EN=%0b, D=%0b, expected Q=%0b, actual Q=%0b", 
                             en_val, d_val, expected_q, q_en);
                    local_errors++;
                end
                vectornum++;
            end
        end
    endtask
    
    // ТЕСТ 4: Распределитель импульсов (ProjVL)
    task test_projvl();
        logic [3:0] expected_q;
        integer local_errors = 0;
        
        $display("\n========== TEST 4: Pulse Distributor (ProjVL) ==========");
        vectornum = 0;
        
        forever begin
            @(posedge clk);
            #1;
            expected_q = testvectors_proj[vectornum];
            if (expected_q === 4'bx) begin
                $display("ProjVL: %d tests completed with %d errors", vectornum, local_errors);
                errors += local_errors;
                break;
            end
            
            @(negedge clk);
            if (~reset) begin
                if (q_proj !== expected_q) begin
                    $display("Error [ProjVL]: expected Q=%b, actual Q=%b", 
                             expected_q, q_proj);
                    local_errors++;
                end
                vectornum++;
            end
        end
    endtask
    
    // ТЕСТ 5: Параллельно-последовательный регистр
    task test_shiftreg();
        logic [5:0] vector;
        logic load_val, expected_serial;
        logic [3:0] parallel_val;
        integer local_errors = 0;
        
        $display("\n========== TEST 5: Parallel-Serial Register ==========");
        vectornum = 0;
        
        forever begin
            @(posedge clk);
            #1;
            vector = testvectors_psr[vectornum];
            if (vector === 6'bx) begin
                $display("Shift Register: %d tests completed with %d errors", vectornum, local_errors);
                errors += local_errors;
                break;
            end
            
            {load_val, parallel_val, expected_serial} = vector;
            load_psr = load_val;
            parallel_data_psr = parallel_val;
            
            @(negedge clk);
            if (~reset) begin
                if (serial_out_psr !== expected_serial) begin
                    $display("Error [Shift Reg]: Load=%0b, Parallel=%b, expected SerialOut=%0b, actual=%0b", 
                             load_val, parallel_val, expected_serial, serial_out_psr);
                    local_errors++;
                end
                vectornum++;
            end
        end
    endtask
    
endmodule